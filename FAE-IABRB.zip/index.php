<?php get_header(); ?>


<?php include "./wp-content/themes/FAE-IABRB/banner-slider.php"?>
<?php include "./wp-content/themes/FAE-IABRB/quick-menu.php"?>
<?php include "./wp-content/themes/FAE-IABRB/highlights.php"?>
<?php include "./wp-content/themes/FAE-IABRB/event-subscriber.php"?>
<?php include "./wp-content/themes/FAE-IABRB/schedule.php"?>



<?php get_footer(); ?>
