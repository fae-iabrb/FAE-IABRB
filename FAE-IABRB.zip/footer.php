<footer class="footer">
  <div class="container">
    <div class="footer-container">
      <ul class="footer-ul">
        <li><a href="#">Home</a>
          <ul>
            <li><a href="#">Institucional</a></li>
            <li><a href="#">Contato</a></li>
            <li><a href="#">Notícias</a></li>
          </ul>
        </li>
        <li><a href="#">Ensino</a>
          <ul>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
          </ul>
        </li>
        <li><a href="#">Pesquisa e Extensão</a></li>
        <li><a href="#">Secretaria</a></li>
        <li><a href="#">Biblioteca</a></li>
        <li><a href="#">Portais Web</a></li>
      </ul>
    </div>
  </div>
</footer>

</body>

</html>
