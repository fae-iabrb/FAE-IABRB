<section class="schedule">
  <div class="container">
  
    <div class="title">AGENDA</div>

    <div class="schedule-container">

      <div class="event-box">

        <div class="data-box">
          <div class="data">22 de Abril</div>
        </div>

        <div class="divider"></div>

        <div class="day-events-box">

        <div class="event">

          <div class="event-title">Morbi maximus, purus at lobortis dictum</div>
          <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi maximus, purus at lobortis</div>
          <div class="event-local">Local: Auditorio IABRB | FAE</div>
          <div class="event-hour">Horário: 19:30</div>

        </div>  

        <div class="event">

          <div class="event-title">Morbi maximus, purus at lobortis dictum</div>
          <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi maximus, purus at lobortis</div>
          <div class="event-local">Local: Auditorio IABRB | FAE</div>
          <div class="event-hour">Horário: 19:30</div>

        </div>  

        </div>

      </div>

      <div class="event-box">

        <div class="data-box">
          <div class="data">28 de Maio</div>
        </div>

        <div class="divider"></div>

        <div class="day-events-box">

          <div class="event">

            <div class="event-title">Morbi maximus, purus at lobortis dictum</div>
            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi maximus, purus at lobortis</div>
            <div class="event-local">Local: Auditorio IABRB | FAE</div>
            <div class="event-hour">Horário: 19:30</div>

          </div>          

        </div>

      </div>
      
    </div>

  </div>
</section>