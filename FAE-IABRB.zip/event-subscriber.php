<section class="event-subscriber">
  <div class="container">

    <div class="title">
      Inscrições de eventos
    </div>

    <div class="events-container">

      <div class="event-box">
        <div class="event-title">VESTIBULAR DE INVERNO</div>
        <div class="event-info">Inscrições até 25 de Junho </div>
        <div class="event-data">02 JUL</div>
      </div>

      <div class="event-box">
        <div class="event-title">VESTIBULAR DE INVERNO</div>
        <div class="event-info">Inscrições até 25 de Junho </div>
        <div class="event-data">02 JUL</div>
      </div>

      <div class="event-box">
        <div class="event-title">VESTIBULAR DE INVERNO</div>
        <div class="event-info">Inscrições até 25 de Junho </div>
        <div class="event-data">02 JUL</div>
      </div>
      
    </div>

  </div>  
  
</section>