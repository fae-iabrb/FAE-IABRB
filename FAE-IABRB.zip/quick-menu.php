<div class="container">
  <div class="quick-menu">
    <div class="box one">
      <img src="<?php echo get_template_directory_uri() ?>/lib/images/quick-menu/basic-education.svg" alt="Educação Basica">
      <div class="title">Educação Basica</div>
    </div>
    <div class="box two">
      <img src="<?php echo get_template_directory_uri() ?>/lib/images/quick-menu/vocational-education.svg" alt="Ensino Profissionalizante">
      <div class="title">Ensino Profissionalizante</div>
    </div>
    <div class="box three">
      <img src="<?php echo get_template_directory_uri() ?>/lib/images/quick-menu/higher-education.svg" alt="Ensino Superior">
      <div class="title">Ensino Superior</div>
    </div>
    <div class="box four">
      <img src="<?php echo get_template_directory_uri() ?>/lib/images/quick-menu/postgraduate-education.svg" alt="Pós-graduação">
      <div class="title">Pós-graduação</div>
    </div>
    <div class="box five">
      <img src="<?php echo get_template_directory_uri() ?>/lib/images/quick-menu/centro-de-idiomas.svg" alt="Centro de Idiomas">
      <div class="title">Centro de Idiomas</div>
    </div>
  </div>
</div>
